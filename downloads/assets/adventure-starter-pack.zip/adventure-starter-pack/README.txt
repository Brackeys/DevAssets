-- INSTRUCTIONS --

If you are using Unity and want to get up an running right away you can open the "Example.unitypackage" which comes with an Example Scene where all of the models have been nicely set up.

If you aren't using Unity - or in case you want to do things yourself - you can import all the individual folders. Each folder includes one to several models (.fbx) with textures (.png, .jpg, .tga).

Some models also come in .blend format in case you are using Blender.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)