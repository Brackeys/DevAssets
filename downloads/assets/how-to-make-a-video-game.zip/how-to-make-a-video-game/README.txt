-- INSTRUCTIONS --

If you want to find a script from a particular video go to the "Scripts" folder and select the corresponding episode. Inside will be the C# scripts used in that video.

If you want to open the entire project in Unity you should first boot up Unity. Then select Open, navigate to the "HowToMakeAVideoGame" folder and hit "Select Folder".

The project will always be the newest available.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)