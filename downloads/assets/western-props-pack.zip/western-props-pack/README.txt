-- INSTRUCTIONS --

If you are using Unity and want to get up an running right away you can open the "Western Props.unitypackage" which also comes with an Example Scene.

If not look under the "Models" folder.

Make sure to import the "Textures" folder along with the model file.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- MADE BY --

This pack was created by Doug Allen and downloaded from http://devassets.com/.

-- HAVE FUN --

I hope you will enjoy the contents of the pack!