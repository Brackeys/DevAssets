-- INSTRUCTIONS --

These assets are from the "Make a Game" course.

It is shown how to use them in the videos.

The models are provided in both .fbx and .blend format. If you do not have Blender installed we recommend using the .fbx versions.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)