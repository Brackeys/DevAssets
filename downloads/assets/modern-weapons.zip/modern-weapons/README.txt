-- INSTRUCTIONS --

If you are using Unity and want to get up an running right away you can open the "Modern Weapons.unitypackage" which also comes with an Example Scene.

If not you can also use the seperate weapon folders.

Each folder contains the model in .fbx format along with all of the textures.

Make sure to import the "Textures" folder along with the model you choose.

-- GUIDELINES --

If you are unsure about how you are allowed to use the assets please see the Usage Guidelines: http://devassets.com/guidelines/

-- HAVE FUN --

I hope you will enjoy the contents of the pack!

(This pack was downloaded from http://devassets.com/.)